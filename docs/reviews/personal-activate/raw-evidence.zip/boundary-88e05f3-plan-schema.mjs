import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';

const ROOT='/workspace/scratch/be43dca0ab34/ultrabrain';
const SHA='88e05f3f84d1cd1ac2e3fdf2f22237c84c6cb3c4';
const source=execFileSync('git',['show',SHA+':test/personal-activate-integration.mjs'],{cwd:ROOT,encoding:'utf8'});
const start=source.indexOf(' async function diagnosePlan(){');
const end=source.indexOf(' async function pending(){',start);
assert.ok(start>=0&&end>start);
const literal=source.slice(start,end);
const make=new Function('run','ROOT','base','secrets','assert','console',literal+';return diagnosePlan;');
const original=JSON.parse(readFileSync('/workspace/scratch/be43dca0ab34/activate-evidence/boundary-88e05f3-plan-safe-envelope.json','utf8'));
const SECRET='PRIVATE_BEARER_SENTINEL_88e05f3';
const fallback={diagnostic:'personal_activation_plan',available:false};
let checks=0;

async function check(name,{mutate,raw,throws=false,code=1,accept=false}={}){
 const value=structuredClone(original);mutate?.(value);
 const messages=[],calls=[];
 const fn=make(async (program,args,options)=>{
  calls.push({program,args,options});if(throws)throw Error(SECRET);
  return {code,text:raw??JSON.stringify(value)};
 },ROOT,['--home','/fixture'],new Set([SECRET]),assert,{log:text=>messages.push(JSON.parse(text))});
 await fn();assert.equal(calls.length,1);
 assert.equal(calls[0].program,'/usr/bin/python3');
 assert.deepEqual(calls[0].args,['-I','-B',ROOT+'/test/personal-activate-crash.py','diagnose-plan','--home','/fixture']);
 assert.deepEqual(calls[0].options,{ok:false,timeout:35000});
 assert.deepEqual(messages,[accept?value:fallback]);
 assert.equal(JSON.stringify(messages).includes(SECRET),false);
 console.log('PASS '+name);checks++;
}

await check('valid fixed schema',{accept:true});
await check('unknown top field',{mutate:v=>v.private='hidden'});
await check('raw unit name rejected',{mutate:v=>v.dependency_failures[0].unit_kind='unlisted-unit.service'});
await check('unknown property rejected',{mutate:v=>v.dependency_failures[0].property='Environment'});
await check('more than eight rows',{mutate:v=>v.dependency_failures=Array(9).fill(v.dependency_failures[0])});
await check('unbounded length rejected',{mutate:v=>v.dependency_failures[0].length=514});
await check('boolean type enforced',{mutate:v=>v.dependency_failures[0].over_limit='false'});
await check('unknown suffix rejected',{mutate:v=>v.dependency_failures[0].invalid_suffixes=['private_suffix']});
await check('duplicate suffix rejected',{mutate:v=>v.dependency_failures[0].invalid_suffixes=['swap','swap']});
await check('raw dependency value rejected',{mutate:v=>v.dependency_failures[0].raw='hidden'});
await check('secret anywhere rejected',{mutate:v=>v.dependency_failures[0].unit_kind=SECRET});
await check('helper exception fallback',{throws:true});
await check('unexpected helper exit fallback',{code:2});
await check('bounded stdout',{raw:' '.repeat(16385)});
await check('malformed json',{raw:'not json'});

const match=source.match(/try\{initial=await plan\(\);\}catch\(error\)\{await diagnosePlan\(\);throw error;\}/);
assert.ok(match);
const execute=new Function('plan','diagnosePlan','return (async()=>{let initial;'+match[0]+';return initial})()');
const first=new Error('ORIGINAL_FAILURE_SENTINEL');let diagnosed=0;
await assert.rejects(execute(async()=>{throw first;},async()=>{diagnosed++;}),error=>error===first);
assert.equal(diagnosed,1);checks++;console.log('PASS original plan error identity preserved');
console.log(JSON.stringify({candidate:SHA,checks,failures:0,scope:'actual extracted JavaScript, controlled helper responses; no service calls'}));
