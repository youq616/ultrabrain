已安装的 console-only 配置停止后，可用 `personal-activate plan/apply` 在核对安装、已有数据库、缓存依赖图与计划摘要后，仅向固定控制台发送一次启动请求。启动中断由账号全局 pending 和持久化 intent/attempt/ack/receipt 记录协调；`recover` 在同一 systemd 255 用户管理器确认旧 sender 消失并建立屏障后，只观察终态或认证 readiness，不重复启动、不停止服务。已有回执的清理明确返回本次未检查就绪。具体合同及命令见 docs/PERSONAL-ACTIVATE.md。

当前候选：9f4e5c2ac81250b7025234fd61008d0bc92e31ef；tree：a03ce02592501574bf03d145cce127fe8eebe5fd。范围限定为已有令牌、数据库已运行的普通 Linux console-only 安装；运行中切换、自动停止回滚及跨 manager 重启恢复不在本阶段。

首轮独立预审发现 device 隐藏 following 依赖，已实际复现并修复。9e85892 获两名独立代码审核 PASS，563 Node / 539 Python 和 15 条历史升级路径通过；服务 CI 的初始 systemctl 夹具失败由受限时间的既有 cache reference 修正。第二候选 071b7f4 越过该夹具步骤，但计划首次查询返回 manager_unavailable。已核对固定 dbus-python 1.3.2 C 源码：同步调用只接受位置参数；本提交修正 timeout 参数形式，并让 FakeBus 采用真实限制，保留修复前失败。49 manager / 合计 120 manager+ready+process 回归通过。18 项新真实激活检查仍待当前提交 CI。

同一首轮候选的 push 并发入队测试失败而 PR 通过；原 stderr 已被旧测试丢弃，不能确定原始错误码。测试现仅对 outbox_busy 用同一事件 ID 有界重试，保留全部成功及精确 ID 断言并加入安全诊断；生产队列不变。本地 capture 51 项与受控竞争/身份错误/重试耗尽检查通过，第二候选两组 portability 均通过。

第三候选 def34fb 的真实 PR 服务 CI 已越过 D-Bus ABI 问题，但首个 plan 在 0 项激活检查时返回 manager_process_unverified；两位独立审核者均对该完整 SHA 给出 BLOCK。此次提交仅新增严格一次性 CI 门槛下的只读诊断，保留原始失败并输出有界固定错误码/栈位置，不修改生产身份检查或派发行为。第四候选 70cd4cc 的实际 push 服务日志已确定，底层为首次读取 /proc/PID/exe 的 PermissionError(errno=13)，尚未到命名空间检查。本提交继续仅扩充有界 CI 诊断，以固定布尔结果区分 UID/GID/文件系统凭据和 capability 条件；原始失败保持不变，生产验证未放宽。第五候选 80d6314 的两组实际诊断进一步确认 UID/GID 全部匹配，但 manager permitted capabilities 非空，而普通调用方 permitted/effective 都为空；命名空间读取同样被拒，不能据此声称不同 namespace。此提交只在一次性 CI 的 user@UID.service 上清空 bounding/ambient 配置，核对缓存后有界重启，并用原生产身份探测与实际无额外 capability 断言验证环境；先检查 CI 进程不在该 manager cgroup 子树。生产身份/派发/恢复逻辑保持严格；文档明确 /proc 可读前提。第六候选 c6b409c 的两组 setup 已完成缓存检查与 restart，但即时 GetNameOwner 查询失败；尚未取得 PID，不能声称实际能力已清空，所有服务场景未执行。当前提交补充精确 D-Bus 错误枚举，并仅对尚未绑定进程的 NameHasNoOwner 做最多 20 次/总 35 秒只读等待；所有其他错误立即失败。重启不重试，成功仍须原生产身份验证及实际 CapPrm 为空。源码确认 READY 可以早于异步 bus 注册；实际是否匹配此状态及是否恢复，仍待当前 CI。

历次真实失败、精确 checkout/tree 和独立报告均已保留。当前阶段 BLOCK，诊断 CI 待执行；全部必要验证完成前保持草稿、不合并 main。
