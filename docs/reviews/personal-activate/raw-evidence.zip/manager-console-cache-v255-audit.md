# systemd v255 console/cache compatibility audit

Date: 2026-09-18 UTC
Investigator: /root/activate_contract_design
Scope: implementer source audit, not a final independent review.
Pinned systemd commit: db11bab38ccf1ed257f310d29070843d4c58ea01 (v255). All thirteen focused source files were re-fetched at this immutable commit and compared with the inspected bytes.

## Outcome

One concrete conditional compatibility bug was confirmed and corrected: passive .swap names in -.slice reverse dependency/ordering properties must be recordable even though any swap or device actually reached by the transaction remains unsupported. See manager-passive-swap-source.md and its before/after evidence. The CI7 failure is not attributed to this defect without the actual diagnostic.

No additional inevitable rejection was found in the examined v255 export signatures, generated console values, command row shapes, or standard implicit dependencies. This is source coverage, not evidence that an arbitrary Ubuntu configuration satisfies the guarded contract.

## Unit cache and edge signatures

All 43 UNIT_CACHE properties exist. All 24 EDGES properties use signature as and the same property_get_dependencies getter in dbus-unit.c:143–177. There is no non-unit-name property accidentally included in EDGES; StopPropagatedFrom is explicitly as at line 879.

| Property | Signature | Getter | Source |
|---|---|---|---|
| Id | s | NULL | [dbus-unit.c:851](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L851) |
| Names | as | property_get_names | [dbus-unit.c:852](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L852) |
| LoadState | s | property_get_load_state | [dbus-unit.c:886](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L886) |
| FragmentPath | s | NULL | [dbus-unit.c:890](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L890) |
| DropInPaths | as | NULL | [dbus-unit.c:892](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L892) |
| NeedDaemonReload | b | property_get_need_daemon_reload | [dbus-unit.c:917](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L917) |
| Following | s | property_get_following | [dbus-unit.c:853](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L853) |
| StopWhenUnneeded | b | bus_property_get_bool | [dbus-unit.c:907](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L907) |
| RefuseManualStart | b | bus_property_get_bool | [dbus-unit.c:908](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L908) |
| RefuseManualStop | b | bus_property_get_bool | [dbus-unit.c:909](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L909) |
| DefaultDependencies | b | bus_property_get_bool | [dbus-unit.c:911](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L911) |
| FailureAction | s | bus_property_get_emergency_action | [dbus-unit.c:935](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L935) |
| SuccessAction | s | bus_property_get_emergency_action | [dbus-unit.c:937](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L937) |
| StartLimitAction | s | bus_property_get_emergency_action | [dbus-unit.c:934](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L934) |
| JobTimeoutAction | s | bus_property_get_emergency_action | [dbus-unit.c:921](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L921) |
| JobTimeoutUSec | t | bus_property_get_usec | [dbus-unit.c:919](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L919) |
| JobRunningTimeoutUSec | t | bus_property_get_usec | [dbus-unit.c:920](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L920) |
| StartLimitIntervalUSec | t | bus_property_get_usec | [dbus-unit.c:932](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L932) |
| StartLimitBurst | u | bus_property_get_unsigned | [dbus-unit.c:933](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L933) |
| Requires | as | property_get_dependencies | [dbus-unit.c:854](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L854) |
| Wants | as | property_get_dependencies | [dbus-unit.c:856](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L856) |
| BindsTo | as | property_get_dependencies | [dbus-unit.c:857](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L857) |
| Upholds | as | property_get_dependencies | [dbus-unit.c:859](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L859) |
| RequiredBy | as | property_get_dependencies | [dbus-unit.c:860](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L860) |
| RequisiteOf | as | property_get_dependencies | [dbus-unit.c:861](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L861) |
| BoundBy | as | property_get_dependencies | [dbus-unit.c:863](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L863) |
| ConsistsOf | as | property_get_dependencies | [dbus-unit.c:865](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L865) |
| PropagatesStopTo | as | property_get_dependencies | [dbus-unit.c:878](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L878) |
| Requisite | as | property_get_dependencies | [dbus-unit.c:855](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L855) |
| PartOf | as | property_get_dependencies | [dbus-unit.c:858](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L858) |
| WantedBy | as | property_get_dependencies | [dbus-unit.c:862](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L862) |
| UpheldBy | as | property_get_dependencies | [dbus-unit.c:864](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L864) |
| Conflicts | as | property_get_dependencies | [dbus-unit.c:866](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L866) |
| ConflictedBy | as | property_get_dependencies | [dbus-unit.c:867](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L867) |
| Before | as | property_get_dependencies | [dbus-unit.c:868](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L868) |
| After | as | property_get_dependencies | [dbus-unit.c:869](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L869) |
| OnFailure | as | property_get_dependencies | [dbus-unit.c:872](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L872) |
| OnSuccess | as | property_get_dependencies | [dbus-unit.c:870](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L870) |
| Triggers | as | property_get_dependencies | [dbus-unit.c:874](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L874) |
| TriggeredBy | as | property_get_dependencies | [dbus-unit.c:875](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L875) |
| PropagatesReloadTo | as | property_get_dependencies | [dbus-unit.c:876](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L876) |
| ReloadPropagatedFrom | as | property_get_dependencies | [dbus-unit.c:877](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L877) |
| StopPropagatedFrom | as | property_get_dependencies | [dbus-unit.c:879](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L879) |

Names uses its own getter (dbus-unit.c:91–121), which emits the unit ID then its alias set without a load-state branch. unit_add_name (unit.c:243–335) initializes the ID before loading and returns early for a previously present name. Missing unit files therefore do not by themselves introduce non-string/empty dependency elements. The full=False path still obtains this same BASE Names property. The existing duplicate rejection is not contradicted by the source.

## Service values and interface exposure

All 35 SERVICE_VALUES properties are exported with compatible signatures. The Service interface combines service, unit-cgroup, cgroup-context, exec-context and kill-context tables; Slice and ControlGroup are available through that interface (dbus.c:521–529).

| Property | Signature | Source |
|---|---|---|
| Type | s | [dbus-service.c:322](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L322) |
| Restart | s | [dbus-service.c:324](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L324) |
| RestartMode | s | [dbus-service.c:325](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L325) |
| RestartUSec | t | [dbus-service.c:328](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L328) |
| RestartSteps | u | [dbus-service.c:329](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L329) |
| RemainAfterExit | b | [dbus-service.c:343](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L343) |
| Slice | s | [dbus-unit.c:1556](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L1556) |
| TimeoutStopUSec | t | [dbus-service.c:333](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L333) |
| TimeoutStartFailureMode | s | [dbus-service.c:335](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L335) |
| TimeoutStopFailureMode | s | [dbus-service.c:336](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L336) |
| KillMode | s | [dbus-kill.c:28](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-kill.c#L28) |
| WorkingDirectory | s | [dbus-execute.c:984](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L984) |
| UMask | u | [dbus-execute.c:951](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L951) |
| NoNewPrivileges | b | [dbus-execute.c:1077](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1077) |
| RestrictSUIDSGID | b | [dbus-execute.c:1103](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1103) |
| StandardInput | s | [dbus-execute.c:1011](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1011) |
| StandardOutput | s | [dbus-execute.c:1014](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1014) |
| StandardError | s | [dbus-execute.c:1016](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1016) |
| LimitCORE | t | [dbus-execute.c:960](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L960) |
| LimitCORESoft | t | [dbus-execute.c:961](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L961) |
| Environment | as | [dbus-execute.c:947](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L947) |
| EnvironmentFiles | a(sb) | [dbus-execute.c:948](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L948) |
| PassEnvironment | as | [dbus-execute.c:949](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L949) |
| UnsetEnvironment | as | [dbus-execute.c:950](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L950) |
| User | s | [dbus-execute.c:1038](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1038) |
| Group | s | [dbus-execute.c:1039](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1039) |
| DynamicUser | b | [dbus-execute.c:1040](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1040) |
| RootDirectory | s | [dbus-execute.c:985](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L985) |
| RootImage | s | [dbus-execute.c:986](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L986) |
| PAMName | s | [dbus-execute.c:1049](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1049) |
| SupplementaryGroups | as | [dbus-execute.c:1048](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1048) |
| PrivateUsers | b | [dbus-execute.c:1065](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1065) |
| RootDirectoryStartOnly | b | [dbus-service.c:342](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L342) |
| RestartPreventExitStatus | (aiai) | [dbus-service.c:345](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L345) |
| RestartForceExitStatus | (aiai) | [dbus-service.c:346](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L346) |

The explicit Type/WorkingDirectory/UMask/NoNewPrivileges/RestrictSUIDSGID/stdio/KillMode/TimeoutStop/Restart/RestartSec/LimitCORE values agree with scripts/personal-services.py:61–80. The unset identity strings, environment lists, root path strings and bool settings follow the zeroed ExecContext initialization ([execute.c:472](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/execute.c#L472)). RestartMode normal and timeout failure mode terminate are the zero-valued service enum members ([service.h:87](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/service.h#L87)); RestartSteps is a zero-initialized unsigned member. Empty restart status sets are exported as a structure containing two int arrays ([dbus-service.c:72](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-service.c#L72)).

## Exec command rows

[dbus-execute.h:16–23](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.h#L16) and [dbus-execute.c:1131–1208](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-execute.c#L1131) confirm ten fields for both forms: path, argv array, boolean/flag-array, four timestamps, PID, exit code, exit status. The existing ten-field check and seven trailing integer fields are correct. Every Exec* and Exec*Ex property currently read is registered in the service vtable. No missing Ex variant was found.

## Implicit dependencies and unit defaults

- Non-instantiated, non-extrinsic user services default to app.slice ([unit.c:3546](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L3546)). Their slice is required and ordered before them ([unit.c:1516](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L1516)).
- User services require basic.target, order after it, and conflict/order before shutdown.target ([service.c:699](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/service.c#L699)). Together with the generated database requirement these support the expected three console Requires entries in the normal generated configuration.
- WorkingDirectory=/ registers mount ordering too ([unit.c:1272](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L1272)); a mount requirement is only added when the mount has a fragment path ([unit.c:1538](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L1538)). The guard does not accidentally hard-code the After list. A real custom root mount fragment could add a requirement and should still be refused by the current exact console contract.
- The root slice is synthesized active/perpetual and has DefaultDependencies=false ([slice.c:109](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/slice.c#L109)). The implementation only requires DefaultDependencies=true for the console, so the root slice is not incorrectly rejected on this value.
- StopWhenUnneeded begins false in the zeroed Unit, and upstream app.slice/session.slice/background.slice do not turn it on. A downstream unit setting true remains an intentional refusal, not a source-derived mismatch.
- Unit default job timeouts are infinity ([unit.c:93](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L93)); the generated console sets its own start limit interval and burst. Emergency action enum zero is none ([emergency-action.h:8](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/emergency-action.h#L8)).
- Following is exported as a string, empty when no canonical following unit is returned. Device/swap transaction following-set behavior is still outside this bounded graph and remains unconditionally refused on actual traversal.

## Verification for the confirmed correction

Preserved first regression: manager-passive-swap-before-fix.log, one test / one error invalid_manager_dependencies.
After repair: manager-passive-swap-after-fix.log, 52 manager tests passed.
Unchanged ready/process suites: manager-passive-swap-ready-process.log, 71 tests passed.
The new fixture checks that passive root RequiredBy/Before swap names are recorded without LoadUnit, runtime observation or transaction membership; separate start/stop/verify arrivals each fail before loading or mutation.
git diff --check passed.

Actual Ubuntu dependency-property values causing CI7 are still unknown until its bounded diagnostic is run. No other production changes were made for unconfirmed possibilities. No services were run during this source audit.

