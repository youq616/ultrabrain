# Passive swap dependency compatibility finding

Date: 2026-09-18 UTC
Investigator: /root/activate_contract_design (implementation/source analysis, not final independent review)
Upstream: systemd v255, immutable commit db11bab38ccf1ed257f310d29070843d4c58ea01.

## Confirmed source-derived defect

The parser rejected .swap in every cached unit-name property, including reverse ordering and requirement facts that are never traversed by this activation transaction. systemd user managers can legitimately expose such passive references from -.slice to host swaps. Rejecting an actual swap in the start/stop/verify closure remains required because this bounded implementation does not inspect the hidden swap following-set inventory.

Source chain:
- [swap.c:1336](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/swap.c#L1336): swap_enumerate reads /proc/swaps without excluding user managers; [swap.c:1370](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/swap.c#L1370) loads those records.
- [swap.c:81](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/swap.c#L81): swaps in user managers are classified as extrinsic.
- [swap.c:344](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/swap.c#L344): loaded/active swaps obtain their default slice.
- [unit.c:3581](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L3581): extrinsic units use the root slice.
- [unit.c:1516](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L1516): cgroup units require and order after their slice, exposing reverse RequiredBy and Before references from -.slice.
- [dbus-unit.c:143](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus-unit.c#L143): dependency properties export related unit IDs; [unit-def.c:79](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/basic/unit-def.c#L79) includes swap as a valid unit type.

The intended correction is to recognize all eleven standard unit-name suffixes in cached facts, while preserving the existing unconditional rejection before LoadUnit whenever graph traversal actually reaches either .device or .swap.

The fixture models an active user-visible swap requiring/ordering after -.slice. With the original parser, test_root_slice_records_passive_swap_without_loading_it fails in names() with invalid_manager_dependencies: one test, one error. The failure log is manager-passive-swap-before-fix.log.

This does not establish that the CI7 invalid_manager_dependencies had this cause. That attribution remains a source-supported hypothesis until the actual bounded CI diagnostic identifies the property and failure shape.

