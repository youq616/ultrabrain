"""Independent reviewer checks; no live systemd, capability, or service changes."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/be43dca0ab34/ultrabrain')
lines = (ROOT/'.github/workflows/personal-services.yml').read_text().splitlines()
blocks, collecting, current = [], False, []
for line in lines:
    if line.startswith('          ') and "<<'PY'" in line:
        assert not collecting
        collecting, current = True, []
    elif collecting and line == '          PY':
        blocks.append(textwrap.dedent('\n'.join(current)))
        collecting = False
    elif collecting:
        current.append(line)
assert not collecting and len(blocks) == 5
CODE = [compile(body, '<workflow-block-'+str(i)+'>', 'exec') for i, body in enumerate(blocks)]
SPEC = importlib.util.spec_from_file_location('reviewed_activation_crash', ROOT/'test/personal-activate-crash.py')
HELPER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HELPER)
ENV = {'GITHUB_ACTIONS':'true', 'ULTRABRAIN_TEST_ALLOW_WRITE':'1', 'ULTRABRAIN_SYSTEMD_TEST':'1',
       'HOME':'/home/runner', 'ULTRABRAIN_HOME':'/home/runner/ultrabrain-personal-services-test'}


class WorkflowFixtureTests(unittest.TestCase):
    def guard(self, raw, *, uid=1001, euid=1001, env=None):
        with tempfile.TemporaryFile() as data:
            data.write(raw); data.seek(0)
            def opened(path, flags):
                self.assertEqual(path, '/proc/self/cgroup')
                self.assertEqual(flags, os.O_RDONLY | os.O_NOFOLLOW)
                return os.dup(data.fileno())
            with patch.object(os, 'getuid', return_value=uid), patch.object(os, 'geteuid', return_value=euid), \
                 patch('pwd.getpwuid', return_value=SimpleNamespace(pw_dir='/home/runner')), \
                 patch.dict(os.environ, ENV if env is None else env, clear=True), patch.object(os, 'open', side_effect=opened):
                exec(CODE[1], {})

    def test_cgroup_guard_accepts_outside_exact_unit_component(self):
        self.guard(b'0::/system.slice/actions.runner.service\n')
        self.guard(b'0::/user.slice/user@10012.service\n')

    def test_cgroup_guard_rejects_target_unit_at_any_depth_or_hierarchy(self):
        for raw in (b'0::/user.slice/user-1001.slice/user@1001.service/init.scope\n',
                    b'2:cpu:/system.slice/runner\n3:pids:/user@1001.service\n'):
            with self.subTest(raw=raw), self.assertRaises(AssertionError):
                self.guard(raw)

    def test_cgroup_guard_rejects_empty_malformed_and_oversized(self):
        for raw in (b'', b'bad\n', b'0::relative\n', b'0::/bad\x00path\n', b'0::/'+b'a'*65537):
            with self.subTest(size=len(raw)), self.assertRaises(AssertionError):
                self.guard(raw)

    def test_cgroup_guard_requires_ordinary_exact_disposable_account(self):
        for options in ({'uid':0,'euid':0}, {'euid':0}, {'env':{**ENV,'GITHUB_ACTIONS':'false'}},
                        {'env':{**ENV,'ULTRABRAIN_HOME':'/home/runner/real-installation'}},
                        {'env':{**ENV,'HOME':'/another-account'}}):
            with self.subTest(options=options), self.assertRaises(AssertionError):
                self.guard(b'0::/system.slice/runner\n', **options)

    def root_write(self, root, *, sudo_uid='1001'):
        original_open = os.open
        def opened(path, flags, *args, **kwargs):
            if path == '/':
                return original_open(root, flags, *args, **kwargs)
            if isinstance(path, str) and path.startswith('/'):
                raise AssertionError('Unexpected absolute access outside redirected temporary root')
            return original_open(path, flags, *args, **kwargs)
        with patch.object(sys, 'argv', ['fixture', '1001']), patch.object(os, 'getuid', return_value=0), \
             patch.object(os, 'geteuid', return_value=0), patch.dict(os.environ, {'SUDO_UID':sudo_uid}, clear=True), \
             patch('pwd.getpwuid', return_value=SimpleNamespace(pw_dir='/home/runner')), \
             patch.object(os, 'open', side_effect=opened):
            exec(CODE[2], {})

    def temporary_root(self):
        t = tempfile.TemporaryDirectory(prefix='review-root-cap-', dir=Path(__file__).parent)
        self.addCleanup(t.cleanup)
        root = Path(t.name)
        (root/'run/systemd').mkdir(parents=True, mode=0o755)
        return root

    def destination(self, root):
        return root/'run/systemd/system/user@1001.service.d/90-ultrabrain-ci-capabilities.conf'

    def test_root_writer_creates_only_exact_empty_capability_dropin(self):
        root = self.temporary_root()
        self.root_write(root)
        dest = self.destination(root)
        self.assertEqual(dest.read_bytes(), b'[Service]\nCapabilityBoundingSet=\nAmbientCapabilities=\n')
        self.assertEqual(dest.stat().st_nlink, 1)
        self.assertEqual(dest.stat().st_mode & 0o777, 0o644)
        self.assertEqual([p for p in root.rglob('*') if p.is_file()], [dest])

    def test_root_writer_never_overwrites_existing_dropin(self):
        root = self.temporary_root()
        dest = self.destination(root); dest.parent.mkdir(parents=True)
        dest.write_bytes(b'preexisting sentinel\n')
        before = dest.stat().st_ino
        with self.assertRaises(FileExistsError):
            self.root_write(root)
        self.assertEqual(dest.read_bytes(), b'preexisting sentinel\n')
        self.assertEqual(dest.stat().st_ino, before)

    def test_root_writer_rejects_symlink_ancestor(self):
        root = self.temporary_root()
        (root/'run/systemd').rmdir()
        target = root/'unrelated'; target.mkdir()
        (root/'run/systemd').symlink_to(target, target_is_directory=True)
        with self.assertRaises(OSError):
            self.root_write(root)
        self.assertEqual(list(target.iterdir()), [])

    def test_root_writer_rejects_unsafe_ancestry(self):
        root = self.temporary_root()
        (root/'run').chmod(0o777)
        with self.assertRaises(AssertionError):
            self.root_write(root)
        self.assertFalse(self.destination(root).exists())

    def test_root_writer_requires_sudo_origin_matching_target(self):
        root = self.temporary_root()
        with self.assertRaises(AssertionError):
            self.root_write(root, sudo_uid='1002')
        self.assertFalse(self.destination(root).exists())

    def cached(self, output, code=0):
        def run(args, **kwargs):
            self.assertEqual(args, ['/usr/bin/systemctl','show','user@1001.service','--no-pager',
                                    '--property=CapabilityBoundingSet,AmbientCapabilities'])
            self.assertEqual(kwargs, {'capture_output':True,'text':True,'timeout':10})
            return SimpleNamespace(returncode=code, stdout=output)
        with patch.object(sys, 'argv', ['fixture','user@1001.service']), patch.object(subprocess, 'run', side_effect=run):
            exec(CODE[3], {})

    def test_cached_check_requires_both_exact_empty_properties(self):
        self.cached('CapabilityBoundingSet=\nAmbientCapabilities=\n')

    def test_cached_check_rejects_capability_missing_duplicate_and_failure(self):
        for output, code in [('CapabilityBoundingSet=CAP_SYS_PTRACE\nAmbientCapabilities=\n',0),
                             ('AmbientCapabilities=\n',0),
                             ('CapabilityBoundingSet=\nAmbientCapabilities=\nAmbientCapabilities=\n',0),
                             ('CapabilityBoundingSet=\nAmbientCapabilities=\n',1)]:
            with self.subTest(output=output, code=code), self.assertRaises(AssertionError):
                self.cached(output, code)

    def postcondition(self, value, code=0):
        def run(args, **kwargs):
            self.assertEqual(args, ['/usr/bin/python3','-I','-B','test/personal-activate-crash.py',
                                    'diagnose-manager','--home',ENV['ULTRABRAIN_HOME']])
            self.assertEqual(kwargs, {'capture_output':True,'text':True,'timeout':35})
            return SimpleNamespace(returncode=code, stdout=json.dumps(value))
        with patch.dict(os.environ, ENV, clear=True), patch.object(subprocess, 'run', side_effect=run), \
             contextlib.redirect_stdout(io.StringIO()):
            exec(CODE[4], {})

    def test_postcondition_accepts_identity_success_and_no_permitted_caps(self):
        self.postcondition({'diagnostic':'personal_activation_manager','ok':True,'exception_chain':[],
                            'proc_checks':{'manager_capprm_nonzero':False}})

    def test_postcondition_refuses_identity_failure_caps_unknown_or_nonzero(self):
        good={'diagnostic':'personal_activation_manager','ok':True,'exception_chain':[],
              'proc_checks':{'manager_capprm_nonzero':False}}
        for value, code in [({**good,'ok':False},1), (good,1),
                            ({**good,'proc_checks':{'manager_capprm_nonzero':True}},0),
                            ({**good,'proc_checks':{'manager_capprm_nonzero':None}},0)]:
            with self.subTest(value=value, code=code), self.assertRaises(AssertionError):
                self.postcondition(value, code)


class DiagnosticTests(unittest.TestCase):
    def test_exception_renderer_hides_message_filename_and_unknown_label(self):
        secret='NEVER_DISCLOSE_PRIVATE_REVIEW_MARKER'
        try:
            try:
                raise PermissionError(13, secret, '/private/'+secret)
            except PermissionError:
                raise RuntimeError(secret) from None
        except RuntimeError as error:
            value=HELPER.safe_diagnostic(error)
        rendered=json.dumps(value)
        self.assertNotIn(secret, rendered)
        self.assertNotIn('/private', rendered)
        self.assertEqual(value['exception_chain'][-1]['errno'],13)
        self.assertLessEqual(sum(len(e['frames']) for e in value['exception_chain']),8)

    def test_status_parser_requires_unique_bounded_typed_fields(self):
        valid=b'Uid:\t1001\t1001\t1001\t1001\nGid:\t1001\t1001\t1001\t1001\nCapPrm:\t0000000000000001\nCapEff:\t0000000000000000\n'
        self.assertEqual(HELPER.diagnostic_status(valid)[b'CapPrm'],1)
        for invalid in (valid+b'CapPrm: 0\n', valid.replace(b'1001',b'4294967296',1),
                        valid.replace(b'0000000000000001',b'not-hex')):
            with self.assertRaises(ValueError):
                HELPER.diagnostic_status(invalid)

    def test_public_diagnostic_root_gate_runs_without_bus_or_installation(self):
        self.assertEqual(os.getuid(),0)
        value=subprocess.run(['/usr/bin/python3','-I','-B',str(ROOT/'test/personal-activate-crash.py'),
                              'diagnose-manager','--home','/not-an-installation'],
                             capture_output=True,text=True,timeout=10)
        self.assertEqual(value.returncode,1)
        self.assertEqual(value.stdout,'')
        self.assertEqual(value.stderr.strip(),'Disposable ordinary-user CI fixture required')


if __name__ == '__main__':
    unittest.main(verbosity=2)
