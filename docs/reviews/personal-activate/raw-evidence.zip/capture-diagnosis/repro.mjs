import {CaptureOutbox} from '../../ultrabrain/src/capture-outbox.mjs';
import {mkdtempSync,mkdirSync,rmSync,existsSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {fileURLToPath} from 'node:url';
const runner=fileURLToPath(new URL('./writer.mjs',import.meta.url));
function setup(){const dir=mkdtempSync(join(tmpdir(),'ub-capture-diagnosis-')),workspace=join(dir,'workspace');mkdirSync(workspace,{mode:0o700});const input={format:1,source:'personal',workspace,outbox_directory:join(dir,'outbox'),allow_capture:true,expected_actor:'a'.repeat(64),expected_instance:'11111111-1111-4111-8111-111111111111',server:{transport:'stdio',command:'node',args:['trusted-server.mjs']}};return{dir,input,q:new CaptureOutbox(input)};}
function child(input,id,hold=0,marker='',retry=0){return new Promise((resolve,reject)=>{const p=spawn(process.execPath,[runner,JSON.stringify(input),id,String(hold),marker,String(retry)],{stdio:['ignore','pipe','pipe']});let stdout='',stderrBytes=0;p.stdout.on('data',b=>stdout+=b);p.stderr.on('data',b=>stderrBytes+=b.length);p.once('error',reject);p.once('close',(exit,signal)=>{let result;try{result=JSON.parse(stdout);}catch{result={diagnostic_json:false};}resolve({exit,signal,...result,stderr_bytes:stderrBytes});});});}
const mode=process.argv[2]??'baseline',rounds=Number(process.argv[3]??20);console.log(JSON.stringify({mode,rounds,node:process.version,platform:process.platform,uid:process.getuid?.()}));
for(let round=0;round<rounds;round++){
  const {dir,input,q}=setup();
  try {
    let results;
    if(mode==='held'||mode==='held-retry'){
      const marker=join(dir,'held'),first=child(input,'owner',1300,marker),end=Date.now()+10000;
      while(!existsSync(marker)&&Date.now()<end)await delay(5);
      if(!existsSync(marker))throw Error('holder did not acquire lock');
      results=await Promise.all([first,...Array.from({length:7},(_,i)=>child(input,'child'+i,0,'',mode==='held-retry'?5000:0))]);
    }else results=await Promise.all(Array.from({length:8},(_,i)=>child(input,'child'+i)));
    const status=await q.status();console.log(JSON.stringify({round,results,pending:status.pending,binding_valid:JSON.parse(readFileSync(join(q.directory,'binding.json'))).binding_sha256===q.bindingHash}));
    if(mode==='baseline'&&results.some(r=>r.exit!==0)){process.exitCode=1;break;}
  }finally{rmSync(dir,{recursive:true,force:true});}
}
