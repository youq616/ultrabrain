# Capture concurrency test diagnosis and narrow correction

- Agent: `/root/capture_ci_diagnosis`.
- Inspected base application commit: `9e85892c54006dedfc7dda2135de3b8f90155347`.
- Scope began read-only; root subsequently authorized a change only to `test/capture-outbox.test.mjs`. This agent implemented that test correction and therefore is not an independent final reviewer of the correction.
- Production outbox code, locks, timeout, profile gates, identity validation and payload handling are unchanged. No commits or pushes were made by this agent.
- All local executions used Linux, Node `v24.19.0`, UID 0 and fresh synthetic temporary directories. No real data, network calls or user services were used. The failed GitHub job used Node `v22.23.2`; local testing does not claim reproduction under that exact Node version.

## Evidence and conclusion

The original GitHub failure is preserved at `../ci-portability-push-first-failure.log`. The test at the original `test/capture-outbox.test.mjs:96` failed after 1361.812286 ms because one or more of eight child exit codes was nonzero. It used `stdio: 'ignore'`, so the original child error code and stderr are unrecoverable from that log. This diagnosis does **not** claim to have directly established the original child error code.

`src/capture-outbox.mjs:89-99` deliberately waits at most about one second for the cooperative queue lock, then throws `outbox_busy`; the shared manifest is read or initialized inside this same queue lock (`:79-99`). A constructor/profile race was not found on inspection. A concurrency test that requires every one-shot enqueue to succeed goes beyond this bounded-contention contract.

- Unmodified production code, unheld baseline: 30 rounds with 8 independent children each; all 240 child processes succeeded, each round contained exactly 8 accepted items, and every binding validated. Maximum child enqueue time was 66 ms. Evidence: `baseline.jsonl`.
- Unmodified production code, controlled holder: in two rounds one writer held its legitimate queue lock in the authorization callback for 1300 ms. All 14 competing children failed specifically with `outbox_busy` after 1003–1016 ms. Each holder succeeded, accepted data was preserved and bindings remained valid. Evidence: `held.jsonl`.
- A preliminary scratch retry prototype also passed two held-lock rounds. Evidence: `held-retry.jsonl`. Final validation below uses the actual runner extracted from the modified repository test, not just this prototype.

These observations support bounded lock contention as a plausible explanation for the original CI failure and establish the test-contract mismatch independently. They do not prove the discarded original stderr contained `outbox_busy`, nor do bounded successful repetitions prove absence of every possible initialization defect.

## Authorized test-only correction

`test/capture-outbox.test.mjs:97-118` now parses each payload once and retries that same event only on `outbox_busy`, with at most 7 retries (8 attempts) and a 10-second retry window. All other errors fail immediately. It reports only a fixed allowlist error code and retry count, never an exception message, payload or raw stderr.

`:119-132` bounds each child's diagnostic output to 1024 bytes, sets a 15-second termination timer, waits for process close and records exit status plus validated safe diagnostics. `:133-135` retains the requirement that all 8 children succeed and exactly 8 entries remain, and additionally checks the stored IDs are precisely `child0` through `child7`.

## Executed final validation

- `node --check test/capture-outbox.test.mjs`: passed.
- `git diff --check`: passed.
- `node --test test/capture-outbox.test.mjs`: 23 passed, 0 failed. Evidence: `capture-tests.log`.
- `node --test test/capture-outbox.test.mjs test/automatic-capture.test.mjs test/capture-hardening.test.mjs test/capture-delivery.test.mjs test/capture-profile-binding.test.mjs`: 51 passed, 0 failed. Evidence: `capture-all-tests.log`.
- `exact-runner-validation.mjs` extracts and executes the actual generated runner from the modified repository test. Two controlled 1300 ms holder rounds each accepted precisely all 8 IDs; every competing child observed one `outbox_busy` before succeeding. A foreign-identity case exited 1 with `identity_mismatch`, zero retries, 75 ms elapsed and no new entry. An 11000 ms holder caused a competing child to exit 1 with `outbox_busy` after exactly 7 retries, 8304 ms elapsed, leaving only the holder's accepted item. Evidence: `exact-runner-validation.jsonl` and its empty stderr file.

The first scratch diagnosis harness had a missing Promise closure and failed with a SyntaxError before imports or fixture operations. It was repaired; that harness-only failure is explicitly preserved in `harness-first-failure.txt`. It was not an application test failure. A progress message briefly misstated the single-file count as 25; the executed result is 23 and was corrected immediately.

Final status: the narrow test correction is implemented and the stated local checks passed. No production correction was justified by the collected evidence. Exact new candidate CI and independent final review remain the root agent's acceptance gates.
