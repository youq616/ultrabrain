
import {CaptureOutbox} from "file:///workspace/scratch/be43dca0ab34/ultrabrain/src/capture-outbox.mjs";
import {setTimeout as delay} from 'node:timers/promises';
let busyRetries=0;
try {
 const q=new CaptureOutbox(JSON.parse(process.argv[2])),payload=JSON.parse(process.argv[3]);
 const deadline=performance.now()+10000;
 for(;;){
  try {await q.enqueue(payload);break;}
  catch(e){
   // The production queue has a bounded lock wait. Replay the same event only
   // for this documented contention outcome; every other error fails at once.
   if(e?.code!=='outbox_busy'||busyRetries>=7||performance.now()>=deadline)throw e;
   busyRetries++;await delay(25);
  }
 }
 process.stdout.write(JSON.stringify({ok:true,busy_retries:busyRetries}));
}catch(e){
 const code=['outbox_busy','identity_mismatch','conflict','insecure_outbox','outbox_corrupt','outbox_unbound','outbox_full','capture_disabled','invalid_profile','invalid_params','outbox_lock_changed'].includes(e?.code)?e.code:'writer_failed';
 process.stdout.write(JSON.stringify({ok:false,code,busy_retries:busyRetries}));process.exitCode=1;
}
