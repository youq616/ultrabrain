import {CaptureOutbox} from '../../ultrabrain/src/capture-outbox.mjs';
import {mkdtempSync,mkdirSync,rmSync,existsSync,readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const testUrl=new URL('../../ultrabrain/test/capture-outbox.test.mjs',import.meta.url);
const testText=readFileSync(testUrl,'utf8');
const marker="const runner=join(dir,'writer.mjs');writeFileSync(runner,";
const start=testText.indexOf(marker)+marker.length,end=testText.indexOf('\n`);',start)+2;
assert.ok(start>=marker.length&&end>start);
const expression=testText.slice(start,end).replaceAll('import.meta.url','testUrl');
const runner=new URL('./actual-repository-writer.mjs',import.meta.url);
writeFileSync(runner,Function('testUrl','return '+expression)(testUrl),{mode:0o600});
const holder=new URL('./writer.mjs',import.meta.url);
function setup(){const dir=mkdtempSync(join(tmpdir(),'ub-capture-exact-')),workspace=join(dir,'workspace');mkdirSync(workspace,{mode:0o700});const input={format:1,source:'personal',workspace,outbox_directory:join(dir,'outbox'),allow_capture:true,expected_actor:'a'.repeat(64),expected_instance:'11111111-1111-4111-8111-111111111111',server:{transport:'stdio',command:'node',args:['trusted-server.mjs']}};return{dir,input,q:new CaptureOutbox(input)};}
const payload=id=>({agent_id:'custom',event_id:id,transcript:'synthetic no-network fixture',consent:true});
function child(script,args){return new Promise((resolve,reject)=>{const start=performance.now(),p=spawn(process.execPath,[fileURLToPath(script),...args],{stdio:['ignore','pipe','pipe']});let stdout='',stderrBytes=0;p.stdout.on('data',b=>stdout+=b);p.stderr.on('data',b=>stderrBytes+=b.length);p.once('error',reject);p.once('close',(exit,signal)=>{let result;try{result=JSON.parse(stdout);}catch{result={diagnostic_json:false};}resolve({exit,signal,...result,stderr_bytes:stderrBytes,elapsed_ms:Math.round(performance.now()-start)});});});}
console.log(JSON.stringify({node:process.version,uid:process.getuid?.(),exact_runner_extracted_from:fileURLToPath(testUrl)}));
for(const mode of ['held-1','held-2','other-error','bounded-busy']){
 const {dir,input,q}=setup();
 try{
  if(mode==='other-error'){
   await q.enqueue(payload('seed'));
   const result=await child(runner,[JSON.stringify({...input,expected_actor:'b'.repeat(64)}),JSON.stringify(payload('foreign'))]);
   assert.equal(result.exit,1);assert.equal(result.code,'identity_mismatch');assert.equal(result.busy_retries,0);assert.equal((await q.status()).pending,1);
   console.log(JSON.stringify({mode,result,pending:1}));continue;
  }
  const marker=join(dir,'held'),hold=mode==='bounded-busy'?11000:1300;
  const first=child(holder,[JSON.stringify(input),'child0',String(hold),marker]);
  const deadline=Date.now()+10000;while(!existsSync(marker)&&Date.now()<deadline)await delay(5);assert.ok(existsSync(marker));
  const results=await Promise.all([first,...Array.from({length:mode==='bounded-busy'?1:7},(_,i)=>child(runner,[JSON.stringify(input),JSON.stringify(payload('child'+(i+1)))]))]);
  const status=await q.status();const ids=readdirSync(q.directory).filter(n=>n.endsWith('.entry')).map(n=>JSON.parse(readFileSync(join(q.directory,n))).payload.event_id).sort();
  if(mode==='bounded-busy'){
   assert.equal(results[1].exit,1);assert.equal(results[1].code,'outbox_busy');assert.equal(results[1].busy_retries,7);assert.equal(status.pending,1);assert.deepEqual(ids,['child0']);
  }else{
   assert.ok(results.every(r=>r.exit===0));assert.ok(results.slice(1).every(r=>r.busy_retries>=1));assert.equal(status.pending,8);assert.deepEqual(ids,Array.from({length:8},(_,i)=>'child'+i));
  }
  console.log(JSON.stringify({mode,results,pending:status.pending,accepted_ids:ids}));
 }finally{rmSync(dir,{recursive:true,force:true});}
}
