import {CaptureOutbox} from '../../ultrabrain/src/capture-outbox.mjs';
import {writeFileSync} from 'node:fs';
import {setTimeout as delay} from 'node:timers/promises';
const started=Date.now();let stage='parse';
try {
  const input=JSON.parse(process.argv[2]),id=process.argv[3],hold=Number(process.argv[4]??0),marker=process.argv[5],retry=Number(process.argv[6]??0);
  stage='constructor';const q=new CaptureOutbox(input);
  stage='enqueue';let result;const prior=[];
  const payload={agent_id:'custom',event_id:id,transcript:'synthetic capture contention fixture',consent:true};
  for(;;){try{result=await q.enqueue(payload,{authorize:()=>{if(marker)writeFileSync(marker,'held',{mode:0o600});if(hold)Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,hold);}});break;}catch(e){if(e?.code!=='outbox_busy'||Date.now()-started>=retry)throw e;prior.push('outbox_busy');await delay(25);}}
  process.stdout.write(JSON.stringify({ok:true,stage,storage:result.storage,prior_errors:prior,elapsed_ms:Date.now()-started})+'\n');
}catch(e){process.stdout.write(JSON.stringify({ok:false,stage,code:typeof e?.code==='string'&&/^[A-Za-z0-9_]+$/.test(e.code)?e.code:'unknown',name:e?.name,elapsed_ms:Date.now()-started})+'\n');process.exitCode=1;}
