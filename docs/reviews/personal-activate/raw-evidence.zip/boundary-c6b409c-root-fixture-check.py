import fcntl
import os
from pathlib import Path
import pwd
import subprocess
import sys
import tempfile
import textwrap
import types
import unittest
from unittest.mock import patch

CANDIDATE = 'c6b409c9864f0d0d97577bde9b2a3d84207ee717'
REPO = '/workspace/scratch/be43dca0ab34/ultrabrain'
workflow = subprocess.run(['git', 'show', CANDIDATE + ':.github/workflows/personal-services.yml'],
                          cwd=REPO, check=True, capture_output=True, text=True).stdout
marker = '          sudo /usr/bin/python3 -I -B - "$fixture_uid" <<\'PY\'\n'
body = textwrap.dedent(workflow.split(marker, 1)[1].split('          PY\n', 1)[0])
compiled = compile(body, 'git:' + CANDIDATE + ':ci-root-dropin', 'exec')


class RootDropinFixtureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / 'run/systemd').mkdir(parents=True)
        self.dest = self.root / 'run/systemd/system/user@1001.service.d/90-ultrabrain-ci-capabilities.conf'

    def tearDown(self):
        self.tmp.cleanup()

    def run_helper(self, uid='1001', sudo_uid='1001', foreign_owner=False):
        opened, foreign_fds = [], set()
        original_open, original_stat = os.open, os.fstat

        def private_open(name, *args, **kwargs):
            is_foreign = foreign_owner and name == 'systemd'
            if name == '/':
                name = str(self.root)
            else:
                self.assertFalse(os.path.isabs(name), 'Only fixed root open may be absolute')
            fd = original_open(name, *args, **kwargs)
            opened.append(fd)
            foreign_fds.discard(fd)
            if is_foreign:
                foreign_fds.add(fd)
            return fd

        def observed_stat(fd):
            value = original_stat(fd)
            if fd in foreign_fds:
                return types.SimpleNamespace(st_uid=1001, st_mode=value.st_mode, st_nlink=value.st_nlink)
            return value

        try:
            with patch.object(os, 'open', side_effect=private_open), \
                    patch.object(os, 'fstat', side_effect=observed_stat), \
                    patch.dict(os.environ, {'SUDO_UID': sudo_uid}), \
                    patch.object(sys, 'argv', ['-', uid]), \
                    patch.object(pwd, 'getpwuid', return_value=types.SimpleNamespace(pw_dir='/home/runner')):
                exec(compiled, {})
        finally:
            for fd in set(opened):
                with self.assertRaises(OSError):
                    fcntl.fcntl(fd, fcntl.F_GETFD)

    def test_create_only_fixed_file_with_exact_empty_capabilities(self):
        self.run_helper()
        self.assertEqual(self.dest.read_bytes(), b'[Service]\nCapabilityBoundingSet=\nAmbientCapabilities=\n')
        self.assertEqual(self.dest.stat().st_uid, 0)
        self.assertEqual(self.dest.stat().st_nlink, 1)

    def test_existing_regular_file_is_not_overwritten(self):
        self.dest.parent.mkdir(parents=True)
        self.dest.write_bytes(b'preserve-existing')
        with self.assertRaises(FileExistsError):
            self.run_helper()
        self.assertEqual(self.dest.read_bytes(), b'preserve-existing')

    def test_existing_file_symlink_is_not_followed(self):
        target = self.root / 'sentinel'
        target.write_bytes(b'preserve-target')
        self.dest.parent.mkdir(parents=True)
        self.dest.symlink_to(target)
        with self.assertRaises(FileExistsError):
            self.run_helper()
        self.assertEqual(target.read_bytes(), b'preserve-target')
        self.assertTrue(self.dest.is_symlink())

    def test_directory_symlink_is_refused(self):
        target = self.root / 'outside'
        target.mkdir()
        (self.root / 'run/systemd/system').symlink_to(target, target_is_directory=True)
        with self.assertRaises(OSError):
            self.run_helper()
        self.assertEqual(list(target.iterdir()), [])

    def test_writable_ancestor_is_refused_before_file_creation(self):
        (self.root / 'run/systemd').chmod(0o777)
        with self.assertRaises(AssertionError):
            self.run_helper()
        self.assertFalse(self.dest.exists())

    def test_foreign_owned_ancestor_is_refused(self):
        # The first actual chown attempt returned EINVAL in this environment;
        # preserve that first log and inject only fstat owner metadata here.
        with self.assertRaises(AssertionError):
            self.run_helper(foreign_owner=True)
        self.assertFalse(self.dest.exists())

    def test_uid_origin_and_canonical_numeric_range_are_required(self):
        with self.assertRaises(AssertionError):
            self.run_helper(sudo_uid='1002')
        for uid in ('0', '01001', '-1', str(2**32)):
            with self.assertRaises(AssertionError):
                self.run_helper(uid=uid, sudo_uid=uid)
        self.assertFalse(self.dest.exists())


if __name__ == '__main__':
    print('Exact workflow source:', CANDIDATE,
          '; private temporary files only; foreign owner uses fstat metadata injection; no sudo/systemctl/loginctl or host /run writes.')
    unittest.main(verbosity=2)
