"""Independent reviewer: exact candidate helper/manager/wait, controlled bus only."""
import contextlib
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import textwrap
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path('/workspace/scratch/be43dca0ab34/ultrabrain')
SHA = '9f4e5c2ac81250b7025234fd61008d0bc92e31ef'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SHA

def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT/relative)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

H = load('reviewed_crash_fixture', 'test/personal-activate-crash.py')
F = load('reviewed_manager_fixtures', 'test/test_personal_activate_manager.py')
M = F.M
lines = (ROOT/'.github/workflows/personal-services.yml').read_text().splitlines()
blocks, body = [], None
for line in lines:
    if line.startswith('          ') and "<<'PY'" in line:
        assert body is None
        body = []
    elif line == '          PY' and body is not None:
        blocks.append(textwrap.dedent('\n'.join(body)))
        body = None
    elif body is not None:
        body.append(line)
assert body is None and len(blocks) == 5
WAIT = compile(blocks[-1], '<actual-candidate-ci-registration-wait>', 'exec')
HOME = '/home/runner/ultrabrain-personal-services-test'
PRIVATE = 'PRIVATE_REVIEW_SENTINEL_NOT_FOR_OUTPUT'

class DBusException(Exception):
    def __init__(self, name):
        super().__init__(PRIVATE)
        self.name = name
    def get_dbus_name(self):
        return self.name
    def __str__(self):
        raise AssertionError('The diagnostic must never stringify a bus error')

class ProbeBus(F.FakeBus):
    def __init__(self, error=None, occurrence=1):
        super().__init__()
        self.error, self.occurrence, self.owner_reads = error, occurrence, 0
    def call_blocking(self, destination, path, interface, method, signature, args, *, timeout):
        if method == 'GetNameOwner' and args == ('org.freedesktop.systemd1',):
            self.owner_reads += 1
            if self.error is not None and self.owner_reads == self.occurrence:
                self.calls.append((destination,path,interface,method,signature,tuple(args),timeout))
                raise DBusException(self.error)
        return super().call_blocking(destination,path,interface,method,signature,args,timeout=timeout)

def observed_proc(pid):
    # This is an injected observation, never an actual manager/capability claim.
    return {'manager_proc_available': pid is not None, 'manager_proc_errno':None,
            'manager_capprm_nonzero':False if pid is not None else None,
            'manager_process_stable':True if pid is not None else None}

def diagnostic(error=None, *, occurrence=1, uid=1000, probe=None):
    bus=ProbeBus(error, occurrence); bus.uid=uid
    manager=M.LocalManager(_connection=bus, _uid=1000, _boot_id=F.BOOT,
        _process_probe=probe or (lambda pid, uid: {'pid':pid,'uid':uid,'start_ticks':100}),
        _message_factory=F.FakeMessage)
    activate=SimpleNamespace(MANAGER=SimpleNamespace(LocalManager=lambda:manager))
    output=io.StringIO()
    with patch.object(H,'diagnostic_proc',side_effect=observed_proc), contextlib.redirect_stdout(output):
        code=H.diagnose_manager(activate)
    assert manager.closed and bus.closed
    assert all(call[3] in {'GetId','GetNameOwner','GetConnectionUnixUser','GetConnectionUnixProcessID','Get'}
               for call in bus.calls)
    assert all(message.auto_start is False and message.interactive is False for message in bus.messages)
    assert PRIVATE not in output.getvalue()
    return SimpleNamespace(returncode=code,stdout=output.getvalue(),stderr=PRIVATE), bus

NO_OWNER='org.freedesktop.DBus.Error.NameHasNoOwner'

class WaitTests(unittest.TestCase):
    def run_wait(self, responses, *, duration=0, exception=None):
        self.calls, self.sleeps, self.clock = [], [], 0.0
        self.output=io.StringIO()
        def run(args,**kw):
            self.assertEqual(args,['/usr/bin/python3','-I','-B','test/personal-activate-crash.py',
                                   'diagnose-manager','--home',HOME])
            self.assertEqual(set(kw),{'capture_output','text','timeout'})
            self.assertIs(kw['capture_output'],True); self.assertIs(kw['text'],True)
            self.assertGreater(kw['timeout'],0); self.assertLessEqual(kw['timeout'],35)
            self.calls.append((args,kw['timeout']))
            if exception is not None: raise exception
            self.clock += duration
            return copy.deepcopy(responses[min(len(self.calls)-1,len(responses)-1)])
        def sleep(seconds):
            self.assertGreater(seconds,0); self.assertLessEqual(seconds,0.5)
            self.sleeps.append(seconds); self.clock += seconds
        with patch.dict(os.environ,{'ULTRABRAIN_HOME':HOME},clear=True), \
             patch.object(subprocess,'run',side_effect=run), \
             patch.object(time,'monotonic',side_effect=lambda:self.clock), \
             patch.object(time,'sleep',side_effect=sleep), contextlib.redirect_stdout(self.output):
            exec(WAIT,{})

    def test_actual_manager_wrapper_no_owner_then_success_closes_both_connections(self):
        absent,_=diagnostic(NO_OWNER); success,_=diagnostic()
        self.assertEqual(json.loads(absent.stdout)['exception_chain'][1]['dbus_error'],'NameHasNoOwner')
        self.run_wait([absent,success],duration=0.1)
        self.assertEqual(len(self.calls),2); self.assertEqual(self.sleeps,[0.5])
        records=[json.loads(line) for line in self.output.getvalue().splitlines()]
        self.assertEqual([v['fixture_setup_attempt'] for v in records],[1,2])
        self.assertEqual([v['ok'] for v in records],[False,True])
        self.assertNotIn(PRIVATE,self.output.getvalue())

    def test_actual_manager_immediate_success_has_no_sleep(self):
        response,_=diagnostic(); self.run_wait([response])
        self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])

    def test_actual_manager_other_bus_errors_never_retry(self):
        for suffix in ['AccessDenied','ServiceUnknown','NoReply','Disconnected',PRIVATE]:
            with self.subTest(suffix=suffix):
                response,_=diagnostic('org.freedesktop.DBus.Error.'+suffix)
                with self.assertRaises(AssertionError): self.run_wait([response])
                self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])
                self.assertNotIn(PRIVATE,self.output.getvalue())

    def test_actual_manager_no_owner_after_pid_binding_never_retries(self):
        response,_=diagnostic(NO_OWNER,occurrence=2)
        self.assertIs(json.loads(response.stdout)['proc_checks']['manager_proc_available'],True)
        with self.assertRaises(AssertionError): self.run_wait([response])
        self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])

    def test_actual_uid_mismatch_and_process_permission_failure_never_retry(self):
        def denied(pid,uid): raise PermissionError(13,PRIVATE)
        for response,_ in [diagnostic(uid=1001),diagnostic(probe=denied)]:
            with self.assertRaises(AssertionError): self.run_wait([response])
            self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])
            self.assertNotIn(PRIVATE,self.output.getvalue())

    def test_no_owner_then_permission_failure_stops_before_third_attempt(self):
        absent,_=diagnostic(NO_OWNER); denied,_=diagnostic('org.freedesktop.DBus.Error.AccessDenied')
        good,_=diagnostic()
        with self.assertRaises(AssertionError): self.run_wait([absent,denied,good])
        self.assertEqual(len(self.calls),2); self.assertEqual(self.sleeps,[0.5])

    def test_persistent_no_owner_stops_at_20_and_retains_first_failure(self):
        absent,_=diagnostic(NO_OWNER)
        with self.assertRaisesRegex(AssertionError,'registration deadline exceeded'):
            self.run_wait([absent])
        self.assertEqual(len(self.calls),20); self.assertEqual(len(self.sleeps),19)
        records=[json.loads(line) for line in self.output.getvalue().splitlines()]
        self.assertEqual(len(records),20); self.assertEqual(records[0]['fixture_setup_attempt'],1)
        self.assertEqual(records[-1]['fixture_setup_attempt'],20)

    def test_elapsed_deadline_stops_with_no_sleep_or_further_attempt(self):
        absent,_=diagnostic(NO_OWNER)
        with self.assertRaisesRegex(AssertionError,'registration deadline exceeded'):
            self.run_wait([absent],duration=35)
        self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])

    def test_subprocess_timeout_is_not_retried(self):
        absent,_=diagnostic(NO_OWNER)
        with self.assertRaises(subprocess.TimeoutExpired):
            self.run_wait([absent],exception=subprocess.TimeoutExpired('fixed-fixture',35))
        self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])

    def test_success_requires_true_identity_and_exact_false_caps(self):
        good,_=diagnostic()
        for caps in (None,True,0,1,'false'):
            value=json.loads(good.stdout); value['proc_checks']['manager_capprm_nonzero']=caps
            bad=SimpleNamespace(returncode=0,stdout=json.dumps(value))
            with self.subTest(caps=caps), self.assertRaises(AssertionError): self.run_wait([bad])
            self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])

    def test_malformed_producer_output_and_invalid_exit_fail_without_retry(self):
        for code,raw in [(0,'{bad'),(1,'{}'),(3,'{}'),(1,'x'*16385)]:
            with self.subTest(code=code,size=len(raw)), self.assertRaises((AssertionError,ValueError,KeyError)):
                self.run_wait([SimpleNamespace(returncode=code,stdout=raw)])
            self.assertEqual(len(self.calls),1); self.assertEqual(self.sleeps,[])

class EnumTests(unittest.TestCase):
    def test_exact_allowlist_rejects_subclasses_similar_names_and_private_getter_results(self):
        class SubString(str): pass
        for value in [None,12,True,{},SubString(NO_OWNER),NO_OWNER+'.'+PRIVATE,PRIVATE,'NameHasNoOwner']:
            with self.subTest(kind=type(value).__name__):
                self.assertIsNone(H.diagnostic_dbus_error(DBusException(value)))
        for suffix in ['NameHasNoOwner','ServiceUnknown','NoReply','Disconnected','AccessDenied']:
            self.assertEqual(H.diagnostic_dbus_error(DBusException('org.freedesktop.DBus.Error.'+suffix)),suffix)

    def test_getter_lookup_and_call_exceptions_return_null_without_rendering(self):
        class LookupErrorObject:
            @property
            def get_dbus_name(self): raise RuntimeError(PRIVATE)
        class CallErrorObject:
            def get_dbus_name(self): raise RuntimeError(PRIVATE)
        for value in [LookupErrorObject(),CallErrorObject(),SimpleNamespace(get_dbus_name=PRIVATE)]:
            self.assertIsNone(H.diagnostic_dbus_error(value))

    def test_public_helper_root_rejection_executes_before_manager_access(self):
        self.assertEqual(os.getuid(),0)
        result=subprocess.run(['/usr/bin/python3','-I','-B',str(ROOT/'test/personal-activate-crash.py'),
                               'diagnose-manager','--home','/not-an-installation'],
                              capture_output=True,text=True,timeout=10)
        self.assertEqual(result.returncode,1); self.assertEqual(result.stdout,'')
        self.assertEqual(result.stderr.strip(),'Disposable ordinary-user CI fixture required')

if __name__ == '__main__': unittest.main(verbosity=2)
