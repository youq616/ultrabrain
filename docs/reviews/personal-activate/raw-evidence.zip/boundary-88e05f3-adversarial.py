"""Independent immutable-candidate review checks; no real manager or service calls."""
import contextlib
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import types
import unittest

ROOT = Path('/workspace/scratch/be43dca0ab34/ultrabrain')
EVIDENCE = ROOT.parent / 'activate-evidence'
SHA = '88e05f3f84d1cd1ac2e3fdf2f22237c84c6cb3c4'
PREVIOUS = '9f4e5c2ac81250b7025234fd61008d0bc92e31ef'
SECRET = 'PRIVATE_BEARER_SENTINEL_88e05f3'


def source(path, sha=SHA):
    return subprocess.check_output(['git', 'show', sha + ':' + path], cwd=ROOT, text=True)


def module(name, path, sha=SHA):
    result = types.ModuleType(name)
    result.__file__ = str(ROOT / path)
    exec(compile(source(path, sha), result.__file__, 'exec'), result.__dict__)
    return result


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SHA
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
T = module('boundary_manager_fixture', 'test/test_personal_activate_manager.py')
M = module('boundary_manager_exact', 'scripts/personal_activate_manager.py')
T.M = M
H = module('boundary_diagnostic_exact', 'test/personal-activate-crash.py')


def fixture(implementation=M):
    bus = T.FakeBus()
    manager = implementation.LocalManager(_connection=bus, _uid=1000, _boot_id=T.BOOT,
        _process_probe=lambda pid, uid: {'pid': pid, 'uid': uid, 'start_ticks': 100},
        _message_factory=T.FakeMessage)
    return bus, manager


class GraphBoundary(unittest.TestCase):
    def rejected(self, suffix, parent, key):
        bus, manager = fixture()
        name = 'dev-independent.' + suffix
        bus.add(name)
        bus.units[parent][key].append(name)
        try:
            with self.assertRaisesRegex(M.ActivateManagerError, '^unsupported_activation_unit$'):
                manager.inspect_start_graph(**T.ARGS)
            self.assertFalse(any(c[3] == 'LoadUnit' and c[5] == (name,) for c in bus.calls))
            self.assertFalse(any(c[3] == 'StartUnit' for c in bus.calls))
        finally:
            manager.close()

    def passive(self, suffix, key):
        bus, manager = fixture()
        name, follower = 'canonical-independent.' + suffix, 'follower-independent.' + suffix
        bus.add(name)
        bus.add(follower)
        bus.units[follower]['Following'] = name
        bus.units[follower]['Wants'] = [M.WORKER]
        bus.units['-.slice'][key].append(name)
        try:
            graph = manager.inspect_start_graph(**T.ARGS)
            self.assertIn(name, graph['contract']['units']['-.slice'][key])
            for hidden in (name, follower, M.WORKER):
                self.assertNotIn(hidden, graph['contract']['units'])
                self.assertNotIn(hidden, graph['observation'])
                for mode in ('start_units', 'stop_units', 'verify_units'):
                    self.assertNotIn(hidden, graph['contract'][mode])
                self.assertFalse(any(c[3] == 'LoadUnit' and c[5] == (hidden,) for c in bus.calls))
            self.assertFalse(any(c[3] == 'StartUnit' for c in bus.calls))
        finally:
            manager.close()

    def test_passive_swap_change_is_not_ignored_on_second_graph_read(self):
        bus, manager = fixture()
        bus.units['-.slice']['RequiredBy'] = ['first.swap']
        def mutate(name, interface, observed):
            if (name, interface) == ('-.slice', M.UNIT) and observed.reads[(name, interface)] == 2:
                observed.units[name]['RequiredBy'] = ['changed.swap']
        bus.mutate = mutate
        try:
            with self.assertRaisesRegex(M.ActivateManagerError, '^activation_graph_changed$'):
                manager.inspect_start_graph(**T.ARGS)
            self.assertFalse(any(c[3] == 'StartUnit' for c in bus.calls))
        finally:
            manager.close()


for suffix in ('device', 'swap'):
    for key in (*M.START_EDGES, 'Conflicts', 'ConflictedBy', 'Requisite'):
        setattr(GraphBoundary, 'test_reject_' + suffix + '_' + key,
            lambda self, suffix=suffix, key=key: self.rejected(suffix, 'basic.target', key))
    for key in M.STOP_EDGES:
        setattr(GraphBoundary, 'test_reject_' + suffix + '_stop_' + key,
            lambda self, suffix=suffix, key=key: self.rejected(suffix, 'shutdown.target', key))
    for key in ('RequiredBy', 'Before', 'After'):
        setattr(GraphBoundary, 'test_passive_' + suffix + '_' + key,
            lambda self, suffix=suffix, key=key: self.passive(suffix, key))


class DiagnosticBoundary(unittest.TestCase):
    def envelope(self, value, present=True, unit=SECRET + '.service'):
        row = H.diagnostic_dependency(M, unit, 'Names', value, present)
        text = json.dumps(row, ensure_ascii=True)
        self.assertNotIn(SECRET, text)
        self.assertEqual(set(row), {'unit_kind', 'property', 'value_type', 'length',
            'over_limit', 'all_strings', 'has_duplicates', 'matches_unit_name',
            'name_over_255', 'invalid_charset', 'invalid_suffixes'})
        self.assertLess(len(text), 2000)
        return row

    def test_duplicate_names_keep_no_names(self):
        row = self.envelope([SECRET + '.service'] * 2)
        self.assertTrue(row['has_duplicates'])
        self.assertTrue(row['matches_unit_name'])
        self.assertEqual(row['unit_kind'], 'other_service')

    def test_invalid_name_categories_without_contents(self):
        row = self.envelope([SECRET + '.unknown', SECRET + '/token.swap', SECRET + '.device',
                             'x' * 270 + '.service'])
        self.assertEqual(row['invalid_suffixes'], ['other', 'service', 'swap'])
        self.assertTrue(row['invalid_charset'])
        self.assertTrue(row['name_over_255'])
        self.assertFalse(row['matches_unit_name'])

    def test_list_over_limit_does_not_traverse_items(self):
        class NoInspect:
            def __str__(self): raise AssertionError('raw object rendered')
            def __repr__(self): raise AssertionError('raw object rendered')
        row = self.envelope([NoInspect()] * 1000)
        self.assertEqual(row['length'], 513)
        self.assertTrue(row['over_limit'])
        self.assertIsNone(row['all_strings'])
        self.assertIsNone(row['matches_unit_name'])

    def test_mixed_items_do_not_stringify_objects(self):
        class NoInspect:
            def __str__(self): raise AssertionError('raw object rendered')
            def __repr__(self): raise AssertionError('raw object rendered')
        row = self.envelope([SECRET, {'private': SECRET}, NoInspect()])
        self.assertFalse(row['all_strings'])
        self.assertIsNone(row['has_duplicates'])
        self.assertEqual(row['invalid_suffixes'], [])

    def test_type_and_missing_categories_are_fixed(self):
        for raw, expected in ((SECRET, 'string'), (3, 'integer'), (True, 'boolean'),
                              ({SECRET: SECRET}, 'object'), (1.5, 'number'), (None, 'null')):
            with self.subTest(expected=expected):
                row = self.envelope(raw)
                self.assertEqual(row['value_type'], expected)
                self.assertIsNone(row['length'])
        self.assertEqual(self.envelope(None, False)['value_type'], 'missing')

    def test_unknown_unit_value_has_no_custom_string_conversion(self):
        class NoInspect:
            def __str__(self): raise AssertionError('raw object rendered')
        self.assertEqual(self.envelope([], unit=NoInspect())['unit_kind'], 'other')

    def execute_diagnostic(self, *, error=False, constructor_error=False, many=False):
        calls = []
        raw = {k: [] for k in M.EDGES}
        raw.update(Id=SECRET + '.service', Names=[SECRET + '.unknown'])
        if many:
            raw = {'Id': SECRET + '.service', 'Names': []}
        service = {'Environment': [SECRET], 'ExecStart': [SECRET]}
        original_error = M.ActivateManagerError('invalid_manager_dependencies')
        class Manager:
            def _all(self, path, interface):
                calls.append(('getall', interface))
                return raw if interface == M.UNIT else service
            def close(self): calls.append(('close',))
            def start_console(self): raise AssertionError('diagnostic attempted service mutation')
        manager = Manager()
        original = manager._all
        class Context:
            def __init__(self, home, *, manager):
                calls.append(('context', home))
                if constructor_error: raise original_error
            def plan(self, **args):
                calls.append(('plan', args))
                assert manager._all('/private/' + SECRET, M.UNIT) is raw
                assert manager._all('/private/' + SECRET, M.SERVICE) is service
                if many:
                    assert manager._all('/private/' + SECRET, M.UNIT) is raw
                if error: raise original_error
                return {'token': SECRET, 'plan': SECRET}
            def apply(self, **args): raise AssertionError('diagnostic applied activation')
            def recover(self, **args): raise AssertionError('diagnostic attempted recovery')
        activate = types.SimpleNamespace(Context=Context, MANAGER=types.SimpleNamespace(
            LocalManager=lambda: manager, UNIT=M.UNIT, EDGES=M.EDGES, names=M.names,
            UNIT_NAME=M.UNIT_NAME, ActivateManagerError=M.ActivateManagerError))
        args = types.SimpleNamespace(home='/private/' + SECRET, bun='/bun', source='personal',
            port=3132, expected_current='a' * 64, expected_instance='11111111-2222-3333-4444-555555555555')
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = H.diagnose_plan(activate, args)
        self.assertEqual(manager._all, original)
        self.assertEqual(sum(c[0] == 'close' for c in calls), 1)
        self.assertEqual(sum(c[0] == 'plan' for c in calls), 0 if constructor_error else 1)
        self.assertNotIn(SECRET, output.getvalue())
        self.assertLess(len(output.getvalue()), 16384)
        return code, json.loads(output.getvalue()), original_error

    def test_diagnostic_preserves_object_and_plan_success(self):
        code, result, _ = self.execute_diagnostic()
        self.assertEqual(code, 0)
        self.assertTrue(result['ok'])
        self.assertEqual(result['exception_chain'], [])
        self.assertEqual(len(result['dependency_failures']), 1)
        self.assertEqual(result['dependency_failures'][0]['property'], 'Names')
        self.assertFalse(result['dependency_failures_truncated'])

    def test_diagnostic_original_failure_safe_and_close(self):
        code, result, _ = self.execute_diagnostic(error=True)
        self.assertEqual(code, 1)
        self.assertFalse(result['ok'])
        self.assertEqual(result['exception_chain'][0]['safe_code'], 'invalid_manager_dependencies')
        (EVIDENCE / 'boundary-88e05f3-plan-safe-envelope.json').write_text(json.dumps(result) + '\n')

    def test_diagnostic_constructor_failure_still_closes(self):
        code, result, _ = self.execute_diagnostic(constructor_error=True)
        self.assertEqual(code, 1)
        self.assertEqual(result['dependency_failures'], [])

    def test_diagnostic_eight_row_cap_across_repeated_unit_getall(self):
        code, result, _ = self.execute_diagnostic(error=True, many=True)
        self.assertEqual(code, 1)
        self.assertEqual(len(result['dependency_failures']), 8)
        self.assertTrue(result['dependency_failures_truncated'])
        self.assertTrue(all(r['property'] in M.EDGES for r in result['dependency_failures']))

    def test_actual_root_refusal_precedes_argument_processing(self):
        self.assertEqual(os.getuid(), 0)
        env = os.environ.copy()
        env.update(GITHUB_ACTIONS='true', ULTRABRAIN_TEST_ALLOW_WRITE='1', ULTRABRAIN_SYSTEMD_TEST='1',
                   ULTRABRAIN_HOME='/root/ultrabrain-personal-services-test')
        result = subprocess.run(['/usr/bin/python3', '-I', '-B',
            str(ROOT / 'test/personal-activate-crash.py'), 'diagnose-plan'], env=env,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, '')
        self.assertEqual(result.stderr, 'Disposable ordinary-user CI fixture required\n')


if __name__ == '__main__':
    print('Exact candidate:', SHA, flush=True)
    unittest.main(verbosity=2)
