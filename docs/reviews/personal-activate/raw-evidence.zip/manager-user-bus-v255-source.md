# systemd v255 user API bus registration source check

Date: 2026-09-18 UTC
Investigator: /root/activate_contract_design
Scope: read-only source investigation for CI6/CI7. This is not a final independent review.
Pinned upstream commit: db11bab38ccf1ed257f310d29070843d4c58ea01 (v255).
All seven source files below were re-fetched at this immutable commit and matched the previously inspected v255 bytes.

## Confirmed conclusions

A successful system-level restart of user@UID.service does not prove that org.freedesktop.systemd1 already has an owner on the user's public bus. The user manager sends its READY notification when basic.target becomes active. Its public API bus name request is asynchronous. This establishes a plausible startup window, but does not establish that CI6 failed only because of timing.

The existing private systemd socket and public user bus are separate paths. systemctl --user normally tries the fixed runtime systemd/private socket and checks its peer, with a user-bus fallback. Therefore a successful systemctl read by itself is not evidence that the production adapter's fixed /run/user/UID/bus name registration succeeded.

The public API connection does not have an unconditional periodic reconnection loop in these paths. Unit state changes cause a bus-state recheck. That recheck attempts connection only when the current manager knows both its dbus.socket to be in SOCKET_RUNNING state and its dbus.service to be in a running/reloading service state. A socket that is only listening does not satisfy the test. A bus that is reachable externally but not represented by those current manager unit states does not satisfy the test either.

SIGUSR1 is not uniformly read-only. If the same socket/service state test passes, the signal handler attempts API bus initialization; that helper is a no-op if an API bus pointer already exists. If the state test fails, the handler requests a start of dbus.service with JOB_REPLACE. It therefore cannot be described or introduced as a harmless reconnect-only operation. No signal was sent or recommended for CI7.

## Immutable source pointers

| Claim | Source and lines |
|---|---|
| User readiness follows basic.target, independent of public bus ownership | [manager.c:3743](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/manager.c#L3743), [manager.c:3779](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/manager.c#L3779) |
| API bus name acquisition uses an asynchronous RequestName call | [dbus.c:816](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus.c#L816) |
| API bus initialization returns immediately if already present, otherwise opens the user bus and attaches it to the event loop | [dbus.c:832](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus.c#L832) |
| Current dbus.socket must be SOCKET_RUNNING and dbus.service running/reloading | [manager.c:1815](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/manager.c#L1815) |
| Initial private API socket is set up unconditionally; public API setup is conditional | [manager.c:1846](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/manager.c#L1846) |
| Unit state notifications invoke the bus-state recheck | [unit.c:2812](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/unit.c#L2812) |
| The recheck connects only with valid unit states, otherwise tears down the API bus connection | [manager.c:4217](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/manager.c#L4217) |
| Disconnection callback tears down the corresponding connection, without an immediate retry | [dbus.c:127](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/dbus.c#L127) |
| SIGUSR1 either initializes API bus or starts dbus.service with JOB_REPLACE | [manager.c:2971](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/core/manager.c#L2971) |
| Official signal documentation describes a reconnection attempt, not guaranteed success | [systemd.xml:430](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/man/systemd.xml#L430) |
| Local systemctl user transport first uses systemd/private | [bus-util.c:234](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/shared/bus-util.c#L234), [bus-util.c:353](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/shared/bus-util.c#L353) |
| User bus address selection prefers DBUS_SESSION_BUS_ADDRESS, then XDG_RUNTIME_DIR | [sd-bus.c:1336](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/libsystemd/sd-bus/sd-bus.c#L1336) |
| Failed asynchronous name requests close the connection; they do not silently prove ownership | [bus-control.c:134](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/libsystemd/sd-bus/bus-control.c#L134) |

## Implications for the current CI experiment

The proposed bounded CI-only wait is appropriate only as an observation experiment: retry an explicitly classified NameHasNoOwner result, read-only, within its fixed deadline. Do not repeat the manager restart or any activation mutation. Any other exception retains its failure.

If ownership appears, the original production identity probe must still establish the same-UID systemd process, zero retained capability result for this fixture, and its complete existing executable/start-ticks/namespace checks. A successful name lookup alone is insufficient.

If NameHasNoOwner persists, the source does not justify further waiting indefinitely. The next useful diagnostic would inspect the current manager's dbus.socket and dbus.service load/state/job facts through a separately identified read-only systemctl/private diagnostic path, together with fixed-address bus identity. Such a diagnostic must remain separate from production dispatch and recovery, which continue to require the fixed public bus.

A lingering externally managed old bus, missing current-manager unit state, address mismatch, failed connection, or failed asynchronous name request are possible persistent failure categories from the source. None is established as the CI6 cause by the available logs. In particular, the existence of a reachable D-Bus daemon does not prove that the current user manager has reached the prerequisite unit states.

No production or test files changed. No service was started, stopped, restarted, or signaled during this source investigation.

